public class SavingsAccount extends BankAccount {
    public static final double MIN_BALANCE = 500;

    public SavingsAccount(String accountNumber, String customerId, double balance) {
        super(accountNumber, customerId, balance);
    }

    @Override
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            addTransaction("DEPOSIT", amount, "SUCCESS");
            System.out.println("Deposited " + amount + ". New balance: " + balance);
        } else {
            addTransaction("DEPOSIT", amount, "FAILED_INVALID_AMOUNT");
            System.out.println("Deposit failed. Amount must be positive.");
        }
    }

    @Override
    public void withdraw(double amount) {
        if (amount <= 0) {
            addTransaction("WITHDRAWAL", amount, "FAILED_INVALID_AMOUNT");
            System.out.println("Withdrawal failed. Amount must be positive.");
            return;
        }
        if (balance - amount >= MIN_BALANCE) {
            balance -= amount;
            addTransaction("WITHDRAWAL", amount, "SUCCESS");
            System.out.println("Withdrew " + amount + ". New balance: " + balance);
        } else {
            addTransaction("WITHDRAWAL", amount, "FAILED_INSUFFICIENT_FUNDS");
            System.out.println("Withdrawal failed. Minimum balance of " + MIN_BALANCE + " required.");
        }
    }
}