import java.util.ArrayList;

public abstract class BankAccount {
    protected String accountNumber;
    protected double balance;
    protected String customerId;
    protected ArrayList<Transaction> transactions;

    public BankAccount(String accountNumber, String customerId, double balance) {
        this.accountNumber = accountNumber;
        this.customerId = customerId;
        this.balance = balance;
        this.transactions = new ArrayList<>();
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public abstract void deposit(double amount);
    public abstract void withdraw(double amount);

    public void transfer(BankAccount destination, double amount) {
        if (destination == null) {
            addTransaction("TRANSFER", amount, "FAILED_INVALID_DESTINATION");
            System.out.println("Transfer failed. Invalid destination account.");
            return;
        }
        if (amount <= 0) {
            addTransaction("TRANSFER", amount, "FAILED_INVALID_AMOUNT");
            System.out.println("Transfer failed. Amount must be positive.");
            return;
        }
        if (this instanceof SavingsAccount && balance - amount < SavingsAccount.MIN_BALANCE) {
            addTransaction("TRANSFER", amount, "FAILED_INSUFFICIENT_FUNDS");
            System.out.println("Transfer failed. Minimum balance of " + SavingsAccount.MIN_BALANCE + " required.");
            return;
        }
        if (this instanceof CheckingAccount && balance - amount < CheckingAccount.OVERDRAFT_LIMIT) {
            addTransaction("TRANSFER", amount, "FAILED_OVERDRAFT_LIMIT");
            System.out.println("Transfer failed. Overdraft limit reached.");
            return;
        }

        balance -= amount;
        destination.deposit(amount);
        addTransaction("TRANSFER_OUT", amount, "SUCCESS");
        destination.addTransaction("TRANSFER_IN", amount, "SUCCESS");
        System.out.println("Transferred " + amount + " to " + destination.getAccountNumber() +
                ". New balance: " + balance);
    }

    public void addTransaction(String type, double amount, String status) {
        transactions.add(new Transaction(type, amount, status));
    }

    public void printTransactions() {
        if (transactions.isEmpty()) {
            System.out.println("No transactions yet.");
        } else {
            for (Transaction t : transactions) {
                System.out.println(t);
            }
        }
    }
}