import java.util.ArrayList;

public class Bank {
    private ArrayList<Customer> customers;

    public Bank() {
        customers = new ArrayList<>();
        initializeSampleData();
    }

    private void initializeSampleData() {
        Customer c1 = new Customer("C1", "Amina", "1234");
        Customer c2 = new Customer("C2", "Zarmeena", "2345");
        Customer c3 = new Customer("C3", "Aisha", "3456");
        Customer c4 = new Customer("C4", "Gulmeena", "4567");
        Customer c5 = new Customer("C5", "Gabeena", "5678");

        c1.addAccount(new SavingsAccount("S1", "C1", 2000));
        c2.addAccount(new CheckingAccount("C2A", "C2", 1500));
        c3.addAccount(new SavingsAccount("S3", "C3", 3000));
        c4.addAccount(new CheckingAccount("C4A", "C4", 2500));
        c5.addAccount(new SavingsAccount("S5", "C5", 1800));

        customers.add(c1);
        customers.add(c2);
        customers.add(c3);
        customers.add(c4);
        customers.add(c5);
    }

    public Customer getCustomer(String id) {
        for (Customer c : customers) {
            if (c.getCustomerId().equalsIgnoreCase(id)) {
                return c;
            }
        }
        return null;
    }

    public void addCustomer(Customer customer) {
        customers.add(customer);
    }

    public String generateCustomerId() {
        int nextId = customers.size() + 1;
        return "C" + nextId;
    }

    public String generateAccountNumber(String customerId, String prefix) {
        int nextId = 1;
        for (Customer c : customers) {
            for (BankAccount acc : c.getAccounts()) {
                if (acc.getAccountNumber().startsWith(prefix + customerId)) {
                    nextId++;
                }
            }
        }
        return prefix + customerId + (nextId > 1 ? nextId : "");
    }

    public ArrayList<Customer> getAllCustomers() {
        return customers;
    }

    public BankAccount findAccount(String accountNumber) {
        for (Customer customer : customers) {
            for (BankAccount account : customer.getAccounts()) {
                if (account.getAccountNumber().equalsIgnoreCase(accountNumber)) {
                    return account;
                }
            }
        }
        return null;
    }
}