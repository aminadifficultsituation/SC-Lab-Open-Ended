import java.util.Scanner;

public class BankAdministrator {
    private Bank bank;
    private Scanner scanner;
    private static final String ADMIN_USERNAME = "nigga";
    private static final String ADMIN_PASSWORD = "niggatron";

    public BankAdministrator(Bank bank) {
        this.bank = bank;
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        System.out.println("\n===== Bank Administrator Login =====");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (!username.equals(ADMIN_USERNAME) || !password.equals(ADMIN_PASSWORD)) {
            System.out.println("Invalid credentials. Access denied.");
            return;
        }

        System.out.println("\nWelcome, Administrator!");
        showAdminMenu();
    }

    private void showAdminMenu() {
        while (true) {
            System.out.println("\n----- Admin Menu -----");
            System.out.println("1. View All Customers");
            System.out.println("2. View All Accounts");
            System.out.println("3. Create New Account");
            System.out.println("4. Unblock Customer Account");
            System.out.println("5. Logout");
            System.out.print("Enter choice: ");

            int choice = getIntInput();
            switch (choice) {
                case 1 -> viewAllCustomers();
                case 2 -> viewAllAccounts();
                case 3 -> createNewAccount();
                case 4 -> unblockCustomerAccount();
                case 5 -> {
                    System.out.println("Logged out from admin interface.");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private void viewAllCustomers() {
        System.out.println("\n===== All Customers =====");
        for (Customer customer : bank.getAllCustomers()) {
            System.out.println("ID: " + customer.getCustomerId() + ", Name: " + customer.getName() +
                    ", Accounts: " + customer.getAccounts().stream()
                    .map(BankAccount::getAccountNumber)
                    .toList());
        }
    }

    private void viewAllAccounts() {
        System.out.println("\n===== All Accounts =====");
        for (Customer customer : bank.getAllCustomers()) {
            for (BankAccount account : customer.getAccounts()) {
                String accountType = (account instanceof SavingsAccount) ? "Savings" : "Checking";
                System.out.println("Type: " + accountType +
                        ", Account Number: " + account.getAccountNumber() +
                        ", Customer ID: " + customer.getCustomerId() +
                        ", Balance: " + account.getBalance());
            }
        }
    }

    private void createNewAccount() {
        System.out.print("Enter Customer ID: ");
        String customerId = scanner.nextLine();
        Customer customer = bank.getCustomer(customerId);
        if (customer == null) {
            System.out.println("Customer not found.");
            return;
        }

        System.out.println("Choose Account Type:");
        System.out.println("1. Savings Account");
        System.out.println("2. Checking Account");
        System.out.print("Enter choice: ");
        int choice = getIntInput();

        System.out.print("Enter initial balance: ");
        double initialBalance = getDoubleInput();
        if (initialBalance < 0) {
            System.out.println("Initial balance cannot be negative.");
            return;
        }

        String accountNumber = bank.generateAccountNumber(customerId, choice == 1 ? "S" : "C");
        BankAccount account = (choice == 1)
                ? new SavingsAccount(accountNumber, customerId, initialBalance)
                : new CheckingAccount(accountNumber, customerId, initialBalance);
        customer.addAccount(account);
        System.out.println("Account " + accountNumber + " created successfully.");
    }

    private void unblockCustomerAccount() {
        System.out.print("Enter Customer ID to unblock: ");
        String customerId = scanner.nextLine();
        Customer customer = bank.getCustomer(customerId);
        if (customer == null) {
            System.out.println("Customer not found.");
            return;
        }
        if (!customer.isBlocked()) {
            System.out.println("Customer account is not blocked.");
            return;
        }
        customer.unblockAccount();
        System.out.println("Customer " + customerId + " account unblocked successfully.");
    }

    private int getIntInput() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Please enter a valid number: ");
            }
        }
    }

    private double getDoubleInput() {
        while (true) {
            try {
                return Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Please enter a valid amount: ");
            }
        }
    }
}