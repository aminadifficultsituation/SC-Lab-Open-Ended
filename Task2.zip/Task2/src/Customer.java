import java.util.ArrayList;

public class Customer {
    private String customerId;
    private String name;
    private String pin;
    private ArrayList<BankAccount> accounts;
    private boolean blocked;
    private int failedAttempts;

    public Customer(String customerId, String name, String pin) {
        this.customerId = customerId;
        this.name = name;
        this.pin = pin;
        this.accounts = new ArrayList<>();
        this.blocked = false;
        this.failedAttempts = 0;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public ArrayList<BankAccount> getAccounts() {
        return accounts;
    }

    public boolean isBlocked() {
        return blocked;
    }

    public void addAccount(BankAccount account) {
        accounts.add(account);
    }

    public boolean validatePin(String inputPin) {
        if (blocked) {
            return false;
        }

        if (this.pin.equals(inputPin)) {
            failedAttempts = 0;
            return true;
        } else {
            failedAttempts++;
            if (failedAttempts >= 3) {
                blockAccount();
            }
            return false;
        }
    }

    public void blockAccount() {
        this.blocked = true;
    }

    public void unblockAccount() {
        this.blocked = false;
        this.failedAttempts = 0;
    }
}