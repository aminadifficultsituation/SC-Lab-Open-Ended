import java.util.Scanner;

public class ATM {
    private Bank bank;
    private Scanner scanner;

    public ATM(Bank bank) {
        this.bank = bank;
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        while (true) {
            System.out.println("\n===== Welcome to the Bank ATM =====");
            System.out.println("1. Customer Login");
            System.out.println("2. Sign Up");
            System.out.println("3. Administrator Login");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");

            int option = getIntInput();

            switch (option) {
                case 1 -> login();
                case 2 -> signUp();
                case 3 -> new BankAdministrator(bank).start();
                case 4 -> {
                    System.out.println("Thank you for using the ATM. Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private void login() {
        System.out.print("Enter Customer ID: ");
        String customerId = scanner.nextLine();

        Customer customer = bank.getCustomer(customerId);
        if (customer == null) {
            System.out.println("Invalid Customer ID. Try again.");
            return;
        }

        if (customer.isBlocked()) {
            System.out.println("Your account is blocked. Please contact the bank.");
            return;
        }

        int attempts = 0;
        while (attempts < 3) {
            System.out.print("Enter PIN: ");
            String pin = scanner.nextLine();

            if (customer.validatePin(pin)) {
                System.out.println("\nWelcome, " + customer.getName() + "!");
                showCustomerMenu(customer);
                return;
            } else {
                attempts++;
                if (attempts < 3) {
                    System.out.println("Incorrect PIN. Try again.");
                }
            }
        }

        customer.blockAccount();
        System.out.println("Your account has been blocked due to 3 incorrect PIN attempts.");
    }

    private void signUp() {
        System.out.println("\n===== Sign Up =====");

        System.out.print("Enter your name: ");
        String name = scanner.nextLine();

        System.out.print("Set a 4-digit PIN: ");
        String pin = scanner.nextLine();

        // Generate new Customer ID automatically
        String newCustomerId = bank.generateCustomerId();
        Customer newCustomer = new Customer(newCustomerId, name, pin);

        System.out.println("Choose Account Type:");
        System.out.println("1. Savings Account");
        System.out.println("2. Checking Account");
        System.out.print("Enter choice: ");
        int choice = getIntInput();

        if (choice == 1) {
            newCustomer.addAccount(new SavingsAccount("S" + newCustomerId, newCustomerId, 0));
        } else {
            newCustomer.addAccount(new CheckingAccount("C" + newCustomerId, newCustomerId, 0));
        }

        bank.addCustomer(newCustomer);
        System.out.println("\nAccount created successfully!");
        System.out.println("Your Customer ID is: " + newCustomerId);
        System.out.println("Use this ID and your PIN to log in next time.");
    }

    private void showCustomerMenu(Customer customer) {
        while (true) {
            System.out.println("\n----- Main Menu -----");
            System.out.println("1. Access Accounts");
            System.out.println("2. Transfer Funds to Another Customer");
            System.out.println("3. Logout");
            System.out.print("Choose an option: ");

            int choice = getIntInput();
            switch (choice) {
                case 1 -> showAccountMenu(customer);
                case 2 -> transferToAnotherCustomer(customer);
                case 3 -> {
                    System.out.println("You have been logged out.");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private void showAccountMenu(Customer customer) {
        while (true) {
            System.out.println("\nSelect Account:");
            for (int i = 0; i < customer.getAccounts().size(); i++) {
                System.out.println((i + 1) + ". " + customer.getAccounts().get(i).getAccountNumber());
            }
            System.out.println("0. Back");
            System.out.print("Enter choice: ");

            int choice = getIntInput();
            if (choice == 0) break;

            if (choice > 0 && choice <= customer.getAccounts().size()) {
                BankAccount selectedAccount = customer.getAccounts().get(choice - 1);
                showOperationsMenu(selectedAccount, customer);
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }

    private void showOperationsMenu(BankAccount account, Customer customer) {
        while (true) {
            System.out.println("\n--- ATM Menu ---");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit Funds");
            System.out.println("3. Withdraw Funds");
            System.out.println("4. Transfer Funds (Same Customer)");
            System.out.println("5. View Transaction History");
            System.out.println("0. Back");
            System.out.print("Enter choice: ");

            int choice = getIntInput();
            switch (choice) {
                case 1 -> System.out.println("Current Balance: " + account.getBalance());
                case 2 -> {
                    System.out.print("Enter amount to deposit: ");
                    double dep = getDoubleInput();
                    if (dep > 0) {
                        account.deposit(dep);
                    } else {
                        System.out.println("Invalid amount. Must be positive.");
                    }
                }
                case 3 -> {
                    System.out.print("Enter amount to withdraw: ");
                    double wit = getDoubleInput();
                    if (wit > 0) {
                        account.withdraw(wit);
                    } else {
                        System.out.println("Invalid amount. Must be positive.");
                    }
                }
                case 4 -> transferWithinCustomer(account, customer);
                case 5 -> account.printTransactions();
                case 0 -> {
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private void transferWithinCustomer(BankAccount sourceAccount, Customer customer) {
        if (customer.getAccounts().size() < 2) {
            System.out.println("You need at least two accounts to transfer funds.");
            return;
        }

        System.out.println("\nSelect Destination Account:");
        for (int i = 0; i < customer.getAccounts().size(); i++) {
            BankAccount acc = customer.getAccounts().get(i);
            if (!acc.getAccountNumber().equals(sourceAccount.getAccountNumber())) {
                System.out.println((i + 1) + ". " + acc.getAccountNumber());
            }
        }
        System.out.print("Enter choice: ");
        int choice = getIntInput();

        BankAccount destAccount = null;
        for (int i = 0; i < customer.getAccounts().size(); i++) {
            if (i + 1 == choice && !customer.getAccounts().get(i).getAccountNumber().equals(sourceAccount.getAccountNumber())) {
                destAccount = customer.getAccounts().get(i);
                break;
            }
        }

        if (destAccount == null) {
            System.out.println("Invalid destination account.");
            return;
        }

        System.out.print("Enter amount to transfer: ");
        double amount = getDoubleInput();
        if (amount <= 0) {
            System.out.println("Invalid amount. Must be positive.");
            return;
        }

        sourceAccount.transfer(destAccount, amount);
    }

    private void transferToAnotherCustomer(Customer customer) {
        System.out.print("Enter destination account number: ");
        String destAccountNumber = scanner.nextLine();
        BankAccount destAccount = bank.findAccount(destAccountNumber);

        if (destAccount == null) {
            System.out.println("Destination account not found.");
            return;
        }

        System.out.println("\nSelect Source Account:");
        for (int i = 0; i < customer.getAccounts().size(); i++) {
            System.out.println((i + 1) + ". " + customer.getAccounts().get(i).getAccountNumber());
        }
        System.out.print("Enter choice: ");
        int choice = getIntInput();

        if (choice <= 0 || choice > customer.getAccounts().size()) {
            System.out.println("Invalid source account.");
            return;
        }

        BankAccount sourceAccount = customer.getAccounts().get(choice - 1);
        System.out.print("Enter amount to transfer: ");
        double amount = getDoubleInput();
        if (amount <= 0) {
            System.out.println("Invalid amount. Must be positive.");
            return;
        }

        sourceAccount.transfer(destAccount, amount);
    }

    private int getIntInput() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Please enter a valid number: ");
            }
        }
    }

    private double getDoubleInput() {
        while (true) {
            try {
                return Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Please enter a valid amount: ");
            }
        }
    }
}