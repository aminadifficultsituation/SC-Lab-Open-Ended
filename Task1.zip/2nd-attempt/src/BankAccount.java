import java.util.ArrayList;

public abstract class BankAccount {
    protected String accountNumber;
    protected double balance;
    protected String customerId;
    protected ArrayList<Transaction> transactions;

    public BankAccount(String accountNumber, String customerId, double balance) {
        this.accountNumber = accountNumber;
        this.customerId = customerId;
        this.balance = balance;
        this.transactions = new ArrayList<>();
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public abstract void deposit(double amount);
    public abstract void withdraw(double amount);

    public void addTransaction(String type, double amount, String status) {
        transactions.add(new Transaction(type, amount, status));
    }

    public void printTransactions() {
        if (transactions.isEmpty()) {
            System.out.println("No transactions yet.");
        } else {
            for (Transaction t : transactions) {
                System.out.println(t);
            }
        }
    }
}
