public class SavingsAccount extends BankAccount {
    private static final double MIN_BALANCE = 500;

    public SavingsAccount(String accountNumber, String customerId, double balance) {
        super(accountNumber, customerId, balance);
    }

    @Override
    public void deposit(double amount) {
        balance += amount;
        addTransaction("DEPOSIT", amount, "SUCCESS");
        System.out.println("Deposited " + amount + ". New balance: " + balance);
    }

    @Override
    public void withdraw(double amount) {
        if (balance - amount >= MIN_BALANCE) {
            balance -= amount;
            addTransaction("WITHDRAWAL", amount, "SUCCESS");
            System.out.println("Withdrew " + amount + ". New balance: " + balance);
        } else {
            addTransaction("WITHDRAWAL", amount, "FAILED_INSUFFICIENT_FUNDS");
            System.out.println("Withdrawal failed. Minimum balance of " + MIN_BALANCE + " required.");
        }
    }
}
